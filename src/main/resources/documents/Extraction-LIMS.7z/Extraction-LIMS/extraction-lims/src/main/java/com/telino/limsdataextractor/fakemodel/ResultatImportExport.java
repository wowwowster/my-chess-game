package com.telino.limsdataextractor.fakemodel;

public class ResultatImportExport {
}
