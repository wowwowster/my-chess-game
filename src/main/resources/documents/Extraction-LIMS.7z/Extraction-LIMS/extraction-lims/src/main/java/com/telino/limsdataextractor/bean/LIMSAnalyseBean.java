package com.telino.limsdataextractor.bean;

public class LIMSAnalyseBean {
}
