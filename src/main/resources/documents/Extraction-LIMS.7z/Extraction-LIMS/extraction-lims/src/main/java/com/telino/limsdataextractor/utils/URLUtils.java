package com.telino.limsdataextractor.utils;

import org.apache.logging.log4j.util.Strings;

import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toList;

public class URLUtils {


}
