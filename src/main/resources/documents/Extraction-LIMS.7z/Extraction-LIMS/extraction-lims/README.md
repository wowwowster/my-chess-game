classes à finir:

    LIMSWebService
    LIMSReponseBean
    ImportApiExterne
    ParametreApiExterne
    ApplicationException
    LIMSImporter
    ResultatImportExport
    LIMSAnalyseBean
